package impossible;
class impossible{
    
    
    
    public static void main(String[] args)
    {
        login log=new login();
        log.start();
    }
}
