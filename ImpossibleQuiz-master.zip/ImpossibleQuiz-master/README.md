Quiz_game
=========
java swing application for a quiz 

A simple quiz game- Impossible in which a user ends the game when the number of wrong answers is 3 . 

Using java swing GUI.

screenshots
===========
![alt tag](https://github.com/gauthamzz/Quiz_game/blob/master/login%20(1).PNG)
![alt tag](https://github.com/gauthamzz/Quiz_game/blob/master/game%20(1).PNG)
![alt tag](https://github.com/gauthamzz/Quiz_game/blob/master/end%20(1).PNG)

